package com.example.mensajeria.models

data class Perfil (
    var name: String = "",
    var foto : Int
        )
